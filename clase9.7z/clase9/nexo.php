<?php

    require_once "./Entidades/AccesoDatos.php";
    require_once "./Entidades/HeladosCarga.php";
    require_once "./Entidades/ConsultarHelado.php";
    require_once "./index.php";

    $app->group("/helados", function(){

        $this->get();

        $this->post("/", \HeladosCarga::class, ":Cargar");

    });

    
?>