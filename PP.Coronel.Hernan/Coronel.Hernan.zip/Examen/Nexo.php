<?php

require_once "./Entidades/Helados.php";

switch($_REQUEST['submit'])
{
    case "heladoCarga":
        Helados::GuardarH($_GET['sabor'],$_GET['precio'],$_GET['tipo'],$_GET['cantidad']);
        break;
    case "consultarHelado":
        echo Helados::ConsultarH($_POST['sabor'],$_POST['tipo']);
        break;
    case "altaVenta":
        Helados::Venta($_POST['email'],$_POST['sabor'],$_POST['tipo'],$_POST['cantidad']);
        break;
    case "altaVentaConImagen":
        Helados::VentaConImagen($_POST['email'],$_POST['sabor'],$_POST['tipo'],$_POST['cantidad']);
        break;
    case "heladoModificacion":
        Helados::Modificar($_POST['nuevosabor'],$_POST['nuevoprecio'],$_POST['nuevotipo'],
        $_POST['nuevacantidad'],$_POST['sabor'],$_POST['tipo']);
        break;

}
?>