<?php

require_once "Entidades/AccesoDatos.php";

class UsuariosCarga
{
    public static function Cargar()
    {        
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
       
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT INTO usuarios (usuario, contraseña)"
                                                        . "VALUES(:usr, :pasw)");
        
        $consulta->bindValue(':usr', $_POST['usuario'], PDO::PARAM_STR);
        $consulta->bindValue(':pasw', $_POST['contrasena'], PDO::PARAM_INT);

        $consulta->execute();
    }
}

?>