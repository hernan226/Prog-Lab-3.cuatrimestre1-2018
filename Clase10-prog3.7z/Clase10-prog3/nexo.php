<?php

    require_once "./Entidades/AccesoDatos.php";
    require_once "./Entidades/HeladosCarga.php";
    require_once "./Entidades/UsuariosCarga.php";
    require_once "./Entidades/ConsultarHelado.php";
    require_once "./Entidades/ConsultarUsuario.php";
    require_once "./vendor/autoload.php";

    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;

    $app = new \Slim\App;

    $app->group("/", function(){
        
                $this->post("/cargarhelado", \HeladosCarga::class . ":Cargar");
        
                $this->post("/consultarhelado", \ConsultarHelado::class . ":Consultar");
    
                $this->post("/cargarusr", \UsuariosCarga::class . ":Cargar");
        
                //$this->post("/login", \ConsultarUsuario::class . ":Consultar");        
            });
    
    $app->run();


?>