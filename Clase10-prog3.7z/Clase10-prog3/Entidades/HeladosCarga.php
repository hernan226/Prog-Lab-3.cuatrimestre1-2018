<?php

require_once "Entidades/AccesoDatos.php";

class HeladosCarga
{
    public static function Cargar()
    {        
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
       
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT INTO helados (sabor, precio, tipo, cantidad)"
                                                            . "VALUES(:sabor, :precio, :tipo, :cantidad)");
        
        $consulta->bindValue(':sabor', $_GET['sabor'], PDO::PARAM_STR);
        $consulta->bindValue(':precio', $_GET['precio'], PDO::PARAM_INT);
        $consulta->bindValue(':tipo', $_GET['tipo'], PDO::PARAM_STR);
        $consulta->bindValue(':cantidad', $_GET['cantidad'], PDO::PARAM_INT);

        $consulta->execute();
    }
}

?>