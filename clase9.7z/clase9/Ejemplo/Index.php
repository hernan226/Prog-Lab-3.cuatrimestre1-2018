<?php
require 'vendor/autoload.php';
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app = new \Slim\App;
$app->get('/hello/{name}', function (Request $request, Response $response, array $args) {
    $name = $args['name'];
    $response->getBody()->write("Hello, $name");
	//pàra retornar objetos provenientes ajax
    return $response;
});
$app->post('/hello', function (Request $request, Response $response, array $args) {
    
	$body = $request->getParsedBody();
	$newResponse = $response->withJson($body->$name, 200);
	//para recibir objetos ajax
    return $newResponse;
});
$app->run();
?>