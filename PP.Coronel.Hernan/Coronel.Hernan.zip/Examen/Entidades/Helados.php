<?php

require_once "./Entidades/Archivos.php";

class Helados
{
    public static function GuardarH($sabor, $precio, $tipo, $cantidad)//get
    {
        Archivos::Guardar("./Archivos/Helados.txt", "$sabor-$tipo-$cantidad-$precio");
    }

    public static function ConsultarH($sabor, $tipo)//post
    {
        $aux = Archivos::Leer("./Archivos/Helados.txt");   
        $haySabor=0; 
        $hayTipo=0;   

        if ($aux!=false)
        {
            
            for($i=0; $i < count($aux)-1 ; $i++)
            {
                $nombre=explode("-",$aux[$i]);
                if(!strcasecmp($nombre[0], $sabor))
                {    
                    $haySabor=1;
                    if(!strcasecmp($nombre[1], $tipo))
                        $hayTipo=1;
                   
                } 
            }
            
        }
        if($hayTipo == 1 && $haySabor == 1)
            return "Si Hay";           

        if($hayTipo == 1 && $haySabor == 0)
            return "Falta el sabor indicado.";
            
        if($hayTipo == 0 && $haySabor == 1)
            return "Falta el tipo indicado.";

        if($hayTipo == 0 && $haySabor == 0)
            return "No existe sabor ni tipo.";
    }

    public static function Venta($email, $sabor, $tipo, $cantidad)//post
    {
        if (Helados::ConsultarH($sabor, $tipo) == "Si Hay")
        {

            $aux = Archivos::Leer("./Archivos/Helados.txt");
            $flag = 0;

            if($aux != false)
            {
                for($i=0; $i < count($aux)-1 ; $i++)
                {
                    $nombre=explode("-",$aux[$i]);
                    if ((int)$nombre[2] >= $cantidad && $nombre[0] == $sabor && $nombre[1 == $tipo])
                    {
                        $flag=1;
                        $nombre[2] = (int)$nombre[2]-$cantidad;
                        $aux[$i] = implode("-", $nombre);
                        break;
                    }
                }
                if ($flag == 1)
                {
                    Archivos::Sobreescribir("./Archivos/Helados.txt", $aux);
                    Archivos::Guardar("./Archivos/Venta.txt", "$email-$sabor-$cantidad-$tipo");
                    
                }
            }

            return $flag;
        } 
    }
    static function GuardarFoto($nombre)
    {
        move_uploaded_file($_FILES['imagen']['tmp_name'], "./ImagenesDeLaVenta/$nombre");        
    }
    public static function VentaConImagen($email, $sabor, $tipo, $cantidad)//post
    {
        $seVendio = Helados::Venta($email, $sabor, $tipo, $cantidad);
        if($seVendio)
            Helados::GuardarFoto("$sabor".date("Ymd").".jpg");
    }

    public static function Modificar($nuevoSabor, $nuevoPrecio, $nuevoTipo, $nuevoCantidad, $sabor, $tipo)//get
    {
        $aux = Archivos::Leer("./Archivos/Helados.txt");

        if($aux != false)
        {
            for ($i=0; $i < count($aux)-1 ; $i++)
            { 
                $explotado = explode("-", $aux[$i]);
                if($explotado[0] == $sabor && $explotado[1] == $tipo)
                {
                    $explotado[0] = $nuevoSabor;
                    $explotado[1] = $nuevoTipo;
                    $explotado[3] = $nuevoPrecio.PHP_EOL;
                    $explotado[2] = $nuevoCantidad;
                    $aux[$i] = implode("-", $explotado);
                    break;
                }
            }
            Archivos::Sobreescribir("./Archivos/Helados.txt", $aux);
        }
    }



}

?>