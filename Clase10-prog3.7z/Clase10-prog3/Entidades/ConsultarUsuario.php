<?php

require_once "Entidades/AccesoDatos.php";

class ConsultarUsuario
{
    public static function Consultar()
    {    
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT usuario AS usuario, contraseña "
                                                        . "AS contraseña, FROM usuarios WHERE "
                                                        . "usuario = :usr AND constraseña = :pasw");
        
        $consulta->execute(array(":usr" => $_POST['sabor'], ":pasw" => $_POST['tipo']));
        
        $cdBuscado = $consulta->fetchObject('ConsultarUsuario');
        
        return $cdBuscado; 
    }
}

?>